import sys

from .enforcer import Enforcer, FunctionMethodEnforcer
